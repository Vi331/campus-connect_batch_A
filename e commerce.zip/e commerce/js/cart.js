/* ===================================================
   SAREE ELEGANCE — cart.js
   Shopping Cart State Management (localStorage)
   =================================================== */

const CART_KEY    = 'saree_elegance_cart';
const WISH_KEY    = 'saree_elegance_wishlist';

// ─── Product Catalog ────────────────────────────────
const PRODUCTS = [
  {
    id: 'p001',
    name: 'Royal Crimson Banarasi',
    category: 'Banarasi Silk',
    price: 8999,
    originalPrice: 12999,
    discount: 31,
    image: 'images/saree_maroon.jpg',
    fabric: 'Pure Banarasi Silk',
    occasion: 'Bridal, Wedding',
    color: '#8B1A2B',
    colorName: 'Crimson',
    badge: 'Bestseller',
    inStock: true,
    rating: 4.8,
    reviews: 124,
    desc: 'An exquisite Banarasi silk saree featuring intricate gold zari work and traditional motifs. Perfect for weddings and grand occasions.'
  },
  {
    id: 'p002',
    name: 'Midnight Blue Kanjeevaram',
    category: 'Kanjeevaram',
    price: 14500,
    originalPrice: 18000,
    discount: 19,
    image: 'images/saree_blue.jpg',
    fabric: 'Pure Kanjeevaram Silk',
    occasion: 'Wedding, Festive',
    color: '#1e3a8a',
    colorName: 'Royal Blue',
    badge: 'New',
    inStock: true,
    rating: 4.9,
    reviews: 89,
    desc: 'A magnificent Kanjeevaram silk saree in deep royal blue with gold temple border motifs, embodying the finest South Indian weaving tradition.'
  },
  {
    id: 'p003',
    name: 'Ivory Pearl Georgette',
    category: 'Georgette',
    price: 3499,
    originalPrice: 4999,
    discount: 30,
    image: 'images/hero_saree_1.jpg',
    fabric: 'Premium Georgette',
    occasion: 'Party, Casual',
    color: '#F5E6C8',
    colorName: 'Ivory',
    badge: 'Sale',
    inStock: true,
    rating: 4.6,
    reviews: 67,
    desc: 'A lightweight georgette saree adorned with delicate pearl embroidery and sequin work, ideal for evening parties and festive gatherings.'
  },
  {
    id: 'p004',
    name: 'Golden Empress Paithani',
    category: 'Paithani',
    price: 11200,
    originalPrice: 15000,
    discount: 25,
    image: 'images/saree_maroon.jpg',
    fabric: 'Pure Silk Paithani',
    occasion: 'Wedding, Festive',
    color: '#C9962C',
    colorName: 'Gold',
    badge: 'Limited',
    inStock: true,
    rating: 4.7,
    reviews: 43,
    desc: 'An opulent Paithani saree with peacock motifs woven in pure gold threads, a masterpiece of Maharashtra weaving artistry.'
  },
  {
    id: 'p005',
    name: 'Emerald Dreams Chanderi',
    category: 'Chanderi',
    price: 2899,
    originalPrice: 3999,
    discount: 27,
    image: 'images/saree_blue.jpg',
    fabric: 'Chanderi Silk Cotton',
    occasion: 'Casual, Office',
    color: '#065f46',
    colorName: 'Emerald',
    badge: 'New',
    inStock: true,
    rating: 4.5,
    reviews: 92,
    desc: 'A graceful Chanderi silk-cotton saree in lush emerald green with fine silver borders. Lightweight and breathable for everyday elegance.'
  },
  {
    id: 'p006',
    name: 'Rose Blush Organza',
    category: 'Organza',
    price: 5499,
    originalPrice: 7500,
    discount: 27,
    image: 'images/hero_saree_1.jpg',
    fabric: 'Pure Organza',
    occasion: 'Party, Evening',
    color: '#be185d',
    colorName: 'Rose Pink',
    badge: null,
    inStock: true,
    rating: 4.7,
    reviews: 55,
    desc: 'A dreamy organza saree in romantic rose blush with floral embroidery and a sheer, ethereal drape perfect for romantic evenings.'
  },
  {
    id: 'p007',
    name: 'Vintage Violet Mysore',
    category: 'Mysore Silk',
    price: 9800,
    originalPrice: 13500,
    discount: 27,
    image: 'images/saree_maroon.jpg',
    fabric: 'Pure Mysore Silk',
    occasion: 'Wedding, Festive',
    color: '#5b21b6',
    colorName: 'Violet',
    badge: null,
    inStock: false,
    rating: 4.9,
    reviews: 31,
    desc: 'A timeless Mysore silk saree in royal violet with zari border and butis. The smoothest silk you will ever drape.'
  },
  {
    id: 'p008',
    name: 'Sunshine Mango Kota',
    category: 'Kota Doria',
    price: 2199,
    originalPrice: 2999,
    discount: 27,
    image: 'images/saree_blue.jpg',
    fabric: 'Kota Doria Cotton Silk',
    occasion: 'Casual, Daily Wear',
    color: '#d97706',
    colorName: 'Mango',
    badge: null,
    inStock: true,
    rating: 4.4,
    reviews: 108,
    desc: 'A vibrant Kota Doria saree in sunny mango yellow with traditional block print borders. Airy and comfortable for summer wear.'
  }
];

// ─── Cart Class ───────────────────────────────────────
class Cart {
  constructor() {
    this.items = this.load();
    this.wishlist = this.loadWish();
    this.listeners = [];
    this.updateUI();
  }

  // Persistence
  load() {
    try {
      return JSON.parse(localStorage.getItem(CART_KEY)) || [];
    } catch { return []; }
  }

  save() {
    localStorage.setItem(CART_KEY, JSON.stringify(this.items));
    this.notify();
    this.updateUI();
  }

  loadWish() {
    try {
      return JSON.parse(localStorage.getItem(WISH_KEY)) || [];
    } catch { return []; }
  }

  saveWish() {
    localStorage.setItem(WISH_KEY, JSON.stringify(this.wishlist));
    this.updateWishUI();
  }

  // Subscribe to changes
  subscribe(fn) {
    this.listeners.push(fn);
    return () => this.listeners = this.listeners.filter(l => l !== fn);
  }

  notify() {
    this.listeners.forEach(fn => fn(this.items));
  }

  // Cart Operations
  add(productId, quantity = 1) {
    const product = PRODUCTS.find(p => p.id === productId);
    if (!product || !product.inStock) return false;

    const existing = this.items.find(i => i.id === productId);
    if (existing) {
      existing.quantity = Math.min(existing.quantity + quantity, 10);
    } else {
      this.items.push({ id: productId, quantity });
    }

    this.save();
    showToast(`${product.name} added to cart!`, 'success');
    return true;
  }

  remove(productId) {
    this.items = this.items.filter(i => i.id !== productId);
    this.save();
    showToast('Item removed from cart', 'info');
  }

  updateQty(productId, quantity) {
    const item = this.items.find(i => i.id === productId);
    if (!item) return;
    if (quantity <= 0) {
      this.remove(productId);
      return;
    }
    item.quantity = Math.min(quantity, 10);
    this.save();
  }

  clear() {
    this.items = [];
    this.save();
  }

  // Getters
  getCount() {
    return this.items.reduce((sum, i) => sum + i.quantity, 0);
  }

  getSubtotal() {
    return this.items.reduce((sum, i) => {
      const product = PRODUCTS.find(p => p.id === i.id);
      return sum + (product ? product.price * i.quantity : 0);
    }, 0);
  }

  getShipping() {
    const subtotal = this.getSubtotal();
    return subtotal >= 2000 ? 0 : 149;
  }

  getTax() {
    return Math.round(this.getSubtotal() * 0.05);
  }

  getTotal() {
    return this.getSubtotal() + this.getShipping() + this.getTax();
  }

  getFullItems() {
    return this.items.map(i => {
      const product = PRODUCTS.find(p => p.id === i.id);
      return product ? { ...product, quantity: i.quantity } : null;
    }).filter(Boolean);
  }

  // Wishlist
  toggleWishlist(productId) {
    const idx = this.wishlist.indexOf(productId);
    if (idx === -1) {
      this.wishlist.push(productId);
      showToast('Added to wishlist ♥', 'success');
    } else {
      this.wishlist.splice(idx, 1);
      showToast('Removed from wishlist', 'info');
    }
    this.saveWish();
    return idx === -1;
  }

  isWishlisted(productId) {
    return this.wishlist.includes(productId);
  }

  // UI Updates
  updateUI() {
    const count = this.getCount();
    document.querySelectorAll('.cart-count').forEach(el => {
      el.textContent = count;
      el.style.display = count > 0 ? 'flex' : 'none';
    });
  }

  updateWishUI() {
    document.querySelectorAll('[data-wish-id]').forEach(btn => {
      const id = btn.dataset.wishId;
      btn.classList.toggle('active', this.isWishlisted(id));
    });
  }
}

// ─── Toast Notifications ─────────────────────────────
function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const icons = {
    success: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>`,
    error:   `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>`,
    info:    `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>`,
  };

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <div class="toast-icon">${icons[type] || icons.info}</div>
    <span>${message}</span>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.animation = 'toastOut 0.4s ease forwards';
    setTimeout(() => toast.remove(), 400);
  }, 3000);
}

// ─── Format Currency ──────────────────────────────────
function formatINR(amount) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
}

// ─── Render Product Card ──────────────────────────────
function renderProductCard(product, cart) {
  const wishlisted = cart ? cart.isWishlisted(product.id) : false;
  const outOfStock = !product.inStock;

  return `
    <div class="product-card reveal" data-product-id="${product.id}">
      <div class="product-card-img silk-shine">
        <img src="${product.image}" alt="${product.name}" loading="lazy"
             onerror="this.style.background='linear-gradient(135deg,#8B1A2B,#C9962C)';this.style.opacity='0.6'">
        ${product.badge ? `<div class="product-card-badge"><span class="badge ${product.badge === 'New' ? 'badge-new' : product.badge === 'Sale' ? 'badge-sale' : 'badge-gold'}">${product.badge}</span></div>` : ''}
        ${outOfStock ? `<div class="product-card-badge"><span class="badge badge-sold">Sold Out</span></div>` : ''}
        <button class="product-card-wish ${wishlisted ? 'active' : ''}" 
                data-wish-id="${product.id}"
                onclick="handleWishlist(event, '${product.id}')"
                title="Add to Wishlist">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="${wishlisted ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2">
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
          </svg>
        </button>
        <div class="product-card-overlay">
          <div class="product-card-actions">
            ${!outOfStock ? `<button class="btn btn-primary w-full btn-sm" onclick="handleAddToCart(event, '${product.id}')">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
              Add to Cart
            </button>` : `<button class="btn btn-outline w-full btn-sm" disabled>Out of Stock</button>`}
          </div>
        </div>
      </div>
      <div class="product-card-body">
        <div class="product-card-category">${product.category}</div>
        <div class="product-card-name" title="${product.name}">${product.name}</div>
        <div class="product-card-price">
          <span class="price-current">${formatINR(product.price)}</span>
          ${product.originalPrice ? `<span class="price-original">${formatINR(product.originalPrice)}</span>` : ''}
          ${product.discount ? `<span class="price-discount">-${product.discount}%</span>` : ''}
        </div>
      </div>
    </div>
  `;
}

// ─── Event Handlers (global) ──────────────────────────
function handleAddToCart(e, productId) {
  e.stopPropagation();
  if (window.cart) {
    window.cart.add(productId);
    const btn = e.currentTarget;
    btn.textContent = '✓ Added!';
    btn.style.background = 'linear-gradient(135deg,#16a34a,#22c55e)';
    setTimeout(() => {
      btn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg> Add to Cart`;
      btn.style.background = '';
    }, 2000);
  }
}

function handleWishlist(e, productId) {
  e.stopPropagation();
  if (window.cart) {
    const added = window.cart.toggleWishlist(productId);
    const btn = e.currentTarget;
    btn.classList.toggle('active', added);
    const svg = btn.querySelector('svg');
    if (svg) svg.setAttribute('fill', added ? 'currentColor' : 'none');
    btn.classList.add('heart-pop');
    setTimeout(() => btn.classList.remove('heart-pop'), 400);
  }
}

// ─── Navigate to Product Page ─────────────────────────
function goToProduct(productId) {
  window.location.href = `product.html?id=${productId}`;
}

// ─── Initialize ───────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
  window.cart = new Cart();
  window.PRODUCTS = PRODUCTS;
  window.formatINR = formatINR;
  window.renderProductCard = renderProductCard;
  window.showToast = showToast;
});
