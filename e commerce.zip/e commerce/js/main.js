/* ===================================================
   SAREE ELEGANCE — main.js
   UI Interactions, Animations, Navigation
   =================================================== */

document.addEventListener('DOMContentLoaded', () => {

  // ─── Navbar Scroll Effect ──────────────────────────
  const navbar = document.querySelector('.navbar');
  if (navbar) {
    const handleScroll = () => {
      navbar.classList.toggle('scrolled', window.scrollY > 60);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
  }

  // ─── Mobile Nav ────────────────────────────────────
  const hamburger  = document.querySelector('.hamburger');
  const mobileNav  = document.querySelector('.mobile-nav');
  const overlay    = document.querySelector('.mobile-nav-overlay');
  const closeBtn   = document.querySelector('.mobile-nav-close');

  function openMobileNav() {
    mobileNav?.classList.add('open');
    overlay?.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closeMobileNav() {
    mobileNav?.classList.remove('open');
    overlay?.classList.remove('open');
    document.body.style.overflow = '';
  }

  hamburger?.addEventListener('click', openMobileNav);
  overlay?.addEventListener('click', closeMobileNav);
  closeBtn?.addEventListener('click', closeMobileNav);

  // ─── Scroll Reveal (IntersectionObserver) ──────────
  const revealElements = document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .reveal-scale');

  if (revealElements.length > 0) {
    const revealObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          revealObserver.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.12,
      rootMargin: '0px 0px -50px 0px'
    });

    revealElements.forEach(el => revealObserver.observe(el));
  }

  // ─── Counter Animation ─────────────────────────────
  const counters = document.querySelectorAll('[data-count]');
  if (counters.length > 0) {
    const countObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          animateCounter(entry.target);
          countObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });

    counters.forEach(el => countObserver.observe(el));
  }

  function animateCounter(el) {
    const target = parseInt(el.dataset.count, 10);
    const suffix = el.dataset.suffix || '';
    const duration = 2000;
    const step = target / (duration / 16);
    let current = 0;

    const timer = setInterval(() => {
      current += step;
      if (current >= target) {
        current = target;
        clearInterval(timer);
      }
      el.textContent = Math.floor(current).toLocaleString('en-IN') + suffix;
    }, 16);
  }

  // ─── Marquee Duplicate ─────────────────────────────
  const marqueeTrack = document.querySelector('.marquee-track');
  if (marqueeTrack) {
    // Duplicate content for infinite scroll
    marqueeTrack.innerHTML += marqueeTrack.innerHTML;
  }

  // ─── Hero Slide Counter ────────────────────────────
  let currentSlide = 0;
  const slides = document.querySelectorAll('.hero-slide');
  const dots = document.querySelectorAll('.slide-dot');

  function goToSlide(idx) {
    slides.forEach((s, i) => s.classList.toggle('active', i === idx));
    dots.forEach((d, i) => d.classList.toggle('active', i === idx));
    currentSlide = idx;
  }

  if (slides.length > 1) {
    setInterval(() => {
      goToSlide((currentSlide + 1) % slides.length);
    }, 6000);

    dots.forEach((dot, i) => dot.addEventListener('click', () => goToSlide(i)));
  }

  // ─── Search Overlay ────────────────────────────────
  const searchBtn    = document.querySelector('#searchBtn');
  const searchOverlay = document.querySelector('#searchOverlay');
  const searchClose  = document.querySelector('#searchClose');
  const searchInput  = document.querySelector('#searchInput');

  searchBtn?.addEventListener('click', () => {
    searchOverlay?.classList.add('open');
    document.body.style.overflow = 'hidden';
    setTimeout(() => searchInput?.focus(), 200);
  });

  searchClose?.addEventListener('click', closeSearch);
  searchOverlay?.addEventListener('click', (e) => {
    if (e.target === searchOverlay) closeSearch();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeSearch();
  });

  function closeSearch() {
    searchOverlay?.classList.remove('open');
    document.body.style.overflow = '';
  }

  // ─── Search Logic ──────────────────────────────────
  if (searchInput) {
    searchInput.addEventListener('input', debounce((e) => {
      const query = e.target.value.toLowerCase().trim();
      const resultsEl = document.querySelector('#searchResults');
      if (!resultsEl || !window.PRODUCTS) return;

      if (query.length < 2) {
        resultsEl.innerHTML = '';
        return;
      }

      const matches = window.PRODUCTS.filter(p =>
        p.name.toLowerCase().includes(query) ||
        p.category.toLowerCase().includes(query) ||
        p.fabric.toLowerCase().includes(query)
      ).slice(0, 5);

      if (matches.length === 0) {
        resultsEl.innerHTML = `<p class="search-no-results">No sarees found for "${query}"</p>`;
        return;
      }

      resultsEl.innerHTML = matches.map(p => `
        <div class="search-result-item" onclick="window.location.href='product.html?id=${p.id}'">
          <img src="${p.image}" alt="${p.name}" onerror="this.style.display='none'">
          <div class="search-result-info">
            <div class="search-result-name">${p.name}</div>
            <div class="search-result-cat">${p.category}</div>
          </div>
          <div class="search-result-price">${window.formatINR ? window.formatINR(p.price) : '₹' + p.price}</div>
        </div>
      `).join('');
    }, 300));
  }

  // ─── Newsletter Form ───────────────────────────────
  const newsletterForm = document.querySelector('#newsletterForm');
  newsletterForm?.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = e.target.querySelector('input[type="email"]').value;
    if (email) {
      showToast('🌸 Thank you for subscribing!', 'success');
      e.target.reset();
    }
  });

  // ─── Smooth Ripple on Buttons ──────────────────────
  document.querySelectorAll('.btn-ripple').forEach(btn => {
    btn.addEventListener('click', function(e) {
      const rect = this.getBoundingClientRect();
      const ripple = document.createElement('span');
      ripple.classList.add('ripple-wave');
      ripple.style.left = `${e.clientX - rect.left}px`;
      ripple.style.top  = `${e.clientY - rect.top}px`;
      this.appendChild(ripple);
      setTimeout(() => ripple.remove(), 700);
    });
  });

  // ─── Product Card Click ────────────────────────────
  document.addEventListener('click', (e) => {
    const card = e.target.closest('.product-card');
    if (card && !e.target.closest('.product-card-wish') && !e.target.closest('.btn')) {
      const id = card.dataset.productId;
      if (id) window.location.href = `product.html?id=${id}`;
    }
  });

  // ─── Filter Toggles (shop page) ───────────────────
  const filterToggles = document.querySelectorAll('.filter-group-title');
  filterToggles.forEach(title => {
    title.style.cursor = 'pointer';
    const options = title.nextElementSibling;
    if (options) {
      title.addEventListener('click', () => {
        const isOpen = options.style.display !== 'none';
        options.style.display = isOpen ? 'none' : '';
        title.style.opacity = isOpen ? '0.6' : '1';
      });
    }
  });

  // ─── Price Range Filter ────────────────────────────
  const minPriceInput = document.querySelector('#minPrice');
  const maxPriceInput = document.querySelector('#maxPrice');
  const applyFilterBtn = document.querySelector('#applyFilters');

  applyFilterBtn?.addEventListener('click', () => {
    applyProductFilters();
  });

  // ─── Sort Products ──────────────────────────────────
  const sortSelect = document.querySelector('#sortBy');
  sortSelect?.addEventListener('change', () => {
    applyProductFilters();
  });

  function applyProductFilters() {
    const grid = document.querySelector('#productGrid');
    if (!grid || !window.PRODUCTS) return;

    let products = [...window.PRODUCTS];

    // Price filter
    const minP = parseInt(minPriceInput?.value) || 0;
    const maxP = parseInt(maxPriceInput?.value) || Infinity;
    products = products.filter(p => p.price >= minP && p.price <= maxP);

    // Category filter
    const checkedCategories = [...document.querySelectorAll('.filter-cat:checked')].map(el => el.value);
    if (checkedCategories.length > 0) {
      products = products.filter(p => checkedCategories.includes(p.category));
    }

    // Sort
    const sortBy = sortSelect?.value || 'default';
    if (sortBy === 'price-asc')   products.sort((a, b) => a.price - b.price);
    if (sortBy === 'price-desc')  products.sort((a, b) => b.price - a.price);
    if (sortBy === 'rating')      products.sort((a, b) => b.rating - a.rating);
    if (sortBy === 'discount')    products.sort((a, b) => b.discount - a.discount);

    grid.innerHTML = products.map(p => window.renderProductCard(p, window.cart)).join('');

    // Re-observe reveal elements
    grid.querySelectorAll('.reveal').forEach(el => el.classList.add('visible'));
  }

  // ─── Utility: Debounce ─────────────────────────────
  function debounce(fn, delay) {
    let timer;
    return function(...args) {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, args), delay);
    };
  }

  // ─── Lazy Image Observer ───────────────────────────
  const lazyImages = document.querySelectorAll('img[loading="lazy"]');
  if ('IntersectionObserver' in window) {
    const imgObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.src = entry.target.dataset.src || entry.target.src;
          imgObserver.unobserve(entry.target);
        }
      });
    });
    lazyImages.forEach(img => imgObserver.observe(img));
  }

  // ─── Sticky nav active link ────────────────────────
  const navLinks = document.querySelectorAll('.nav-link');
  const currentPath = window.location.pathname.split('/').pop() || 'index.html';
  navLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (href === currentPath || (currentPath === '' && href === 'index.html')) {
      link.classList.add('active');
    }
  });

});

// ─── Quantity Controls (reusable) ─────────────────────
function changeQty(productId, delta) {
  if (!window.cart) return;
  const item = window.cart.items.find(i => i.id === productId);
  if (!item) return;
  window.cart.updateQty(productId, item.quantity + delta);
}

// ─── Global helper for showToast ─────────────────────
window.showToast = window.showToast || function(msg, type) {
  console.log(`[${type}] ${msg}`);
};
